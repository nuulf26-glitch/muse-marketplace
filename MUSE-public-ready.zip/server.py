from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path
import sqlite3, json, hashlib, hmac, secrets, time, os, base64, mimetypes, uuid, math, shutil
from data import COUNTRIES, CITIES

ROOT=Path(__file__).resolve().parent
STATIC=ROOT/'static'
DB=Path(os.environ.get('MUSE_DB', str(ROOT/'muse.db'))).expanduser()
UPLOADS=Path(os.environ.get('MUSE_UPLOADS_DIR', str(STATIC/'uploads'))).expanduser()
SESSION_DAYS=30
# MUSE is always a real-account marketplace.  Older deployments may still
# have MUSE_DEMO_MODE set, but it is intentionally ignored.
DEMO_MODE=False
SECURE_COOKIES=os.environ.get('MUSE_SECURE_COOKIES','').strip().lower() in ('1','true','yes','on')
MAX_REQUEST_BYTES=8*1024*1024
MAX_UPLOAD_BYTES=6*1024*1024
ALLOWED_UPLOAD_EXTENSIONS={'.jpg','.jpeg','.png','.webp','.gif','.pdf','.doc','.docx','.xls','.xlsx','.ppt','.pptx','.zip'}


def now(): return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
def uid(prefix): return f"{prefix}_{uuid.uuid4().hex[:14]}"
def db():
    DB.parent.mkdir(parents=True,exist_ok=True)
    c=sqlite3.connect(DB,timeout=10); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); c.execute('PRAGMA busy_timeout=5000'); return c

def clean_text(value,limit=2000):
    return str(value or '').strip()[:limit]

def money_value(value,minimum=0):
    try:
        amount=float(value)
    except (TypeError,ValueError):
        return None
    if not math.isfinite(amount) or amount<minimum:
        return None
    return round(amount,2)

def whole_number(value,minimum=1):
    try:
        amount=int(value)
    except (TypeError,ValueError):
        return None
    return amount if amount>=minimum else None

def session_cookie(token='',max_age=0):
    parts=[f'muse_session={token}','Path=/','HttpOnly','SameSite=Lax',f'Max-Age={max_age}']
    if SECURE_COOKIES: parts.append('Secure')
    return '; '.join(parts)

def uploaded_url(value):
    value=clean_text(value,300)
    if not value.startswith('/uploads/') or '/' in value[len('/uploads/'):]:return ''
    return value

def upload_file_from_path(path):
    """Return a safe persisted upload for a public /uploads/ request."""
    if not path.startswith('/uploads/'): return None
    filename=path[len('/uploads/'):]
    if not filename or '/' in filename or '\\' in filename: return None
    target=UPLOADS/filename
    return target if target.is_file() else None

def hash_password(password, salt=None):
    salt=salt or secrets.token_hex(16)
    digest=hashlib.pbkdf2_hmac('sha256',password.encode(),salt.encode(),120000).hex()
    return salt+'$'+digest

def verify_password(password, stored):
    try:
        salt,digest=stored.split('$',1)
        actual=hashlib.pbkdf2_hmac('sha256',password.encode(),salt.encode(),120000).hex()
        return hmac.compare_digest(actual,digest)
    except Exception:return False

def ensure_column(c,table,column,definition):
    columns={row['name'] for row in c.execute(f'PRAGMA table_info({table})')}
    if column not in columns:c.execute(f'ALTER TABLE {table} ADD COLUMN {column} {definition}')

def bootstrap_admin(c):
    email=clean_text(os.environ.get('MUSE_BOOTSTRAP_ADMIN_EMAIL',''),254).lower()
    password=os.environ.get('MUSE_BOOTSTRAP_ADMIN_PASSWORD','')
    if not email or not password or len(password)<8:return
    if c.execute('SELECT 1 FROM users WHERE email=?',(email,)).fetchone():return
    name=clean_text(os.environ.get('MUSE_BOOTSTRAP_ADMIN_NAME','MUSE Admin'),120) or 'MUSE Admin'
    add_user(c,uid('admin'),email,password,'admin',name,1,{})

def create_deal_for_offer(c,offer,agreed_price):
    existing=c.execute('SELECT id FROM deals WHERE offer_id=?',(offer['id'],)).fetchone()
    if existing:return existing['id']
    deal_id=uid('deal')
    c.execute(
        '''INSERT INTO deals(
            id,brand_id,talent_id,campaign_id,offer_id,title,agreed_price,
            currency,deliverables,deadline,status,created_at
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
        (deal_id,offer['brand_id'],offer['talent_id'],None,offer['id'],offer['title'],agreed_price,offer['currency'],offer['deliverables'],offer['date'],'Accepted',now())
    )
    return deal_id

def public_user(row):
    if not row:return None
    d=dict(row); d.pop('password_hash',None)
    p=json.loads(d.pop('profile_json') or '{}'); d.update(p)
    d['verified']=bool(d.get('verified')); d['suspended']=bool(d.get('suspended'))
    if 'onboardingComplete' not in d:
        d['onboardingComplete'] = bool(d.get('bio')) or d.get('role') == 'admin'
    return d

def is_live_profile(user):
    """Profiles remain private until their owner completes onboarding."""
    return bool(user and user.get('onboardingComplete') and not user.get('suspended'))

def init_db():
    c=db()
    c.execute('PRAGMA journal_mode=WAL')
    c.executescript('''
    CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL,name TEXT NOT NULL,verified INTEGER DEFAULT 0,suspended INTEGER DEFAULT 0,profile_json TEXT DEFAULT '{}',created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires INTEGER NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS campaigns(id TEXT PRIMARY KEY,brand_id TEXT NOT NULL,name TEXT NOT NULL,description TEXT,talent_type TEXT,category TEXT,country TEXT,city TEXT,platform TEXT,deliverables TEXT,budget_min REAL,budget_max REAL,currency TEXT DEFAULT 'USD',deadline TEXT,slots INTEGER DEFAULT 1,visibility TEXT DEFAULT 'Public',status TEXT DEFAULT 'Open',created_at TEXT NOT NULL,FOREIGN KEY(brand_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS applications(id TEXT PRIMARY KEY,campaign_id TEXT NOT NULL,talent_id TEXT NOT NULL,proposal TEXT,price REAL,status TEXT DEFAULT 'Applied',created_at TEXT NOT NULL,FOREIGN KEY(campaign_id) REFERENCES campaigns(id),FOREIGN KEY(talent_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS campaign_invites(id TEXT PRIMARY KEY,campaign_id TEXT NOT NULL,talent_id TEXT NOT NULL,status TEXT DEFAULT 'Invited',created_at TEXT NOT NULL,UNIQUE(campaign_id,talent_id),FOREIGN KEY(campaign_id) REFERENCES campaigns(id),FOREIGN KEY(talent_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS offers(id TEXT PRIMARY KEY,brand_id TEXT NOT NULL,talent_id TEXT NOT NULL,title TEXT,details TEXT,deliverables TEXT,date TEXT,price REAL,currency TEXT DEFAULT 'USD',status TEXT DEFAULT 'Pending',created_at TEXT NOT NULL,FOREIGN KEY(brand_id) REFERENCES users(id),FOREIGN KEY(talent_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS deals(id TEXT PRIMARY KEY,brand_id TEXT NOT NULL,talent_id TEXT NOT NULL,campaign_id TEXT,offer_id TEXT,title TEXT,agreed_price REAL,currency TEXT DEFAULT 'USD',deliverables TEXT,deadline TEXT,status TEXT DEFAULT 'Accepted',created_at TEXT NOT NULL,FOREIGN KEY(brand_id) REFERENCES users(id),FOREIGN KEY(talent_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS deal_messages(id TEXT PRIMARY KEY,deal_id TEXT NOT NULL,from_user TEXT NOT NULL,text TEXT,file_name TEXT,file_url TEXT,created_at TEXT NOT NULL,FOREIGN KEY(deal_id) REFERENCES deals(id),FOREIGN KEY(from_user) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS collaboration_requests(id TEXT PRIMARY KEY,talent_id TEXT NOT NULL,brand_id TEXT NOT NULL,note TEXT,status TEXT DEFAULT 'Pending',created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(talent_id,brand_id),FOREIGN KEY(talent_id) REFERENCES users(id),FOREIGN KEY(brand_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS collaboration_messages(id TEXT PRIMARY KEY,request_id TEXT NOT NULL,from_user TEXT NOT NULL,text TEXT,file_name TEXT,file_url TEXT,created_at TEXT NOT NULL,FOREIGN KEY(request_id) REFERENCES collaboration_requests(id),FOREIGN KEY(from_user) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS favorites(brand_id TEXT NOT NULL,talent_id TEXT NOT NULL,PRIMARY KEY(brand_id,talent_id));
    CREATE TABLE IF NOT EXISTS shortlists(id TEXT PRIMARY KEY,brand_id TEXT NOT NULL,name TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(brand_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS shortlist_talent(shortlist_id TEXT NOT NULL,talent_id TEXT NOT NULL,PRIMARY KEY(shortlist_id,talent_id));
    CREATE TABLE IF NOT EXISTS notifications(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,text TEXT NOT NULL,read INTEGER DEFAULT 0,created_at TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id));
    ''')
    ensure_column(c,'offers','counter_price','REAL')
    ensure_column(c,'offers','counter_note','TEXT')
    ensure_column(c,'offers','countered_at','TEXT')
    ensure_column(c,'deals','payment_plan',"TEXT DEFAULT 'Not set'")
    ensure_column(c,'deals','payment_status',"TEXT DEFAULT 'Not set'")
    ensure_column(c,'deals','payment_note','TEXT')
    ensure_column(c,'deals','payment_sent_at','TEXT')
    ensure_column(c,'deals','payment_received_at','TEXT')
    bootstrap_admin(c)
    c.commit(); c.close()
    UPLOADS.mkdir(parents=True,exist_ok=True)

def add_user(c,id,email,password,role,name,verified=0,profile=None):
    c.execute('INSERT INTO users VALUES(?,?,?,?,?,?,?,?,?)',(id,email,hash_password(password),role,name,verified,0,json.dumps(profile or {}),now()))

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(STATIC),**kwargs)
    def log_message(self,fmt,*args): print('[MUSE]',fmt%args)
    def end_headers(self):
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','strict-origin-when-cross-origin')
        self.send_header('Permissions-Policy','camera=(), microphone=(), geolocation=()')
        self.send_header('Content-Security-Policy',"default-src 'self'; connect-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; font-src 'self' data:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'")
        super().end_headers()
    def send_json(self,obj,status=200,cookie=None):
        body=json.dumps(obj,ensure_ascii=False).encode(); self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(body))); self.send_header('Cache-Control','no-store');
        if cookie:self.send_header('Set-Cookie',cookie)
        self.end_headers(); self.wfile.write(body)
    def body(self):
        try:
            length=int(self.headers.get('Content-Length','0') or 0)
            if length>MAX_REQUEST_BYTES:
                self.send_json({'error':'Request is too large.'},413)
                return None
            return json.loads(self.rfile.read(length) or b'{}')
        except:return {}
    def cookies(self):
        out={}
        for part in (self.headers.get('Cookie') or '').split(';'):
            if '=' in part:
                k,v=part.strip().split('=',1); out[k]=v
        return out
    def me(self,c):
        token=self.cookies().get('muse_session')
        if not token:return None
        row=c.execute('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires>?',(token,int(time.time()))).fetchone()
        return public_user(row)
    def require(self,c,roles=None):
        u=self.me(c)
        if not u:self.send_json({'error':'Authentication required'},401); return None
        if u.get('suspended'):self.send_json({'error':'Account suspended'},403); return None
        if roles and u['role'] not in roles:self.send_json({'error':'Not allowed'},403); return None
        return u
    def serve_upload(self,path):
        target=upload_file_from_path(path)
        if not target:return self.send_error(404)
        try:
            size=target.stat().st_size
            content_type=mimetypes.guess_type(str(target))[0] or 'application/octet-stream'
            self.send_response(200)
            self.send_header('Content-Type',content_type)
            self.send_header('Content-Length',str(size))
            self.send_header('Cache-Control','private, max-age=3600')
            if target.suffix.lower() not in {'.jpg','.jpeg','.png','.webp','.gif'}:
                self.send_header('Content-Disposition',f'attachment; filename="{target.name}"')
            self.end_headers()
            with target.open('rb') as source: shutil.copyfileobj(source,self.wfile)
        except OSError:
            self.send_error(404)
    def do_GET(self):
        p=urlparse(self.path); path=p.path
        if not path.startswith('/api/'):
            if path.startswith('/uploads/'):
                return self.serve_upload(path)
            if path!='/' and not (STATIC/path.lstrip('/')).exists(): self.path='/index.html'
            return super().do_GET()
        c=db()
        try:
            if path=='/api/meta': return self.send_json({'countries':COUNTRIES,'cities':CITIES,'demoMode':DEMO_MODE})
            if path=='/api/me': return self.send_json({'user':self.me(c)})
            if path=='/api/talents':
                fav=[]; me=self.me(c)
                if me and me['role']=='brand': fav=[r['talent_id'] for r in c.execute('SELECT talent_id FROM favorites WHERE brand_id=?',(me['id'],))]
                rows=[u for u in (public_user(r) for r in c.execute("SELECT * FROM users WHERE role='talent' AND suspended=0 ORDER BY verified DESC, created_at DESC")) if is_live_profile(u)]
                return self.send_json({'talents':rows,'favorites':fav})
            if path.startswith('/api/talents/'):
                r=c.execute("SELECT * FROM users WHERE id=? AND role='talent' AND suspended=0",(path.split('/')[-1],)).fetchone()
                talent=public_user(r)
                return self.send_json({'talent':talent},200 if is_live_profile(talent) else 404)
            if path.startswith('/api/brands/'):
                bid=path.split('/')[-1]
                r=c.execute("SELECT * FROM users WHERE id=? AND role='brand' AND suspended=0",(bid,)).fetchone()
                if not r:return self.send_json({'error':'Brand not found'},404)
                brand=public_user(r)
                if not is_live_profile(brand):return self.send_json({'error':'Brand not found'},404)
                campaigns=[dict(x) for x in c.execute("SELECT c.*,u.name brand_name,u.verified brand_verified FROM campaigns c JOIN users u ON u.id=c.brand_id WHERE c.brand_id=? AND c.status!='Deleted' AND c.visibility='Public' ORDER BY c.created_at DESC",(bid,))]
                request=None; me=self.me(c)
                if me and me['role']=='talent':
                    request=c.execute('SELECT id,status,note,created_at,updated_at FROM collaboration_requests WHERE talent_id=? AND brand_id=?',(me['id'],bid)).fetchone()
                return self.send_json({'brand':brand,'campaigns':campaigns,'collaborationRequest':dict(request) if request else None})
            if path=='/api/campaigns':
                me=self.me(c)
                base=[dict(r) for r in c.execute('SELECT c.*,u.name brand_name,u.verified brand_verified FROM campaigns c JOIN users u ON u.id=c.brand_id WHERE c.status!=? ORDER BY c.created_at DESC',('Deleted',))]
                rows=[]
                for row in base:
                    row['invited']=False
                    if row.get('visibility')=='Public': rows.append(row); continue
                    if me and (me.get('role')=='admin' or (me.get('role')=='brand' and row.get('brand_id')==me.get('id'))): rows.append(row); continue
                    if me and me.get('role')=='talent':
                        inv=c.execute('SELECT status FROM campaign_invites WHERE campaign_id=? AND talent_id=?',(row['id'],me['id'])).fetchone()
                        if inv:
                            row['invited']=True; row['invite_status']=inv['status']; rows.append(row)
                return self.send_json({'campaigns':rows})
            if path.startswith('/api/campaigns/'):
                cid=path.split('/')[-1]
                r=c.execute('SELECT c.*,u.name brand_name,u.verified brand_verified FROM campaigns c JOIN users u ON u.id=c.brand_id WHERE c.id=?',(cid,)).fetchone()
                if not r:return self.send_json({'campaign':None},404)
                row=dict(r); me=self.me(c); row['invited']=False
                if row.get('visibility')=='Invite Only':
                    allowed=bool(me and (me.get('role')=='admin' or (me.get('role')=='brand' and me.get('id')==row.get('brand_id'))))
                    if me and me.get('role')=='talent':
                        inv=c.execute('SELECT status FROM campaign_invites WHERE campaign_id=? AND talent_id=?',(cid,me['id'])).fetchone()
                        if inv: allowed=True; row['invited']=True; row['invite_status']=inv['status']
                    if not allowed:return self.send_json({'error':'This campaign is invite only.'},403)
                return self.send_json({'campaign':row})
            if path=='/api/dashboard':
                u=self.require(c); 
                if not u:return
                if u['role']=='brand':
                    offers=[dict(r) for r in c.execute('SELECT o.*,u.name talent_name FROM offers o JOIN users u ON u.id=o.talent_id WHERE brand_id=? ORDER BY o.created_at DESC',(u['id'],))]
                    deals=[dict(r) for r in c.execute('SELECT d.*,u.name talent_name FROM deals d JOIN users u ON u.id=d.talent_id WHERE brand_id=? ORDER BY d.created_at DESC',(u['id'],))]
                    apps=[dict(r) for r in c.execute('SELECT a.*,u.name talent_name,c.name campaign_name FROM applications a JOIN users u ON u.id=a.talent_id JOIN campaigns c ON c.id=a.campaign_id WHERE c.brand_id=? ORDER BY a.created_at DESC',(u['id'],))]
                    fav=[public_user(r) for r in c.execute("SELECT u.* FROM favorites f JOIN users u ON u.id=f.talent_id WHERE f.brand_id=?",(u['id'],))]
                    requests=[]
                    for row in c.execute('SELECT r.*,u.name talent_name,u.verified talent_verified,u.profile_json FROM collaboration_requests r JOIN users u ON u.id=r.talent_id WHERE r.brand_id=? ORDER BY r.updated_at DESC',(u['id'],)):
                        item=dict(row); profile=json.loads(item.pop('profile_json') or '{}'); item.update(profile); item['talent_verified']=bool(item.get('talent_verified')); requests.append(item)
                    lists=[]
                    for l in c.execute('SELECT * FROM shortlists WHERE brand_id=?',(u['id'],)):
                        d=dict(l); d['talentIds']=[x['talent_id'] for x in c.execute('SELECT talent_id FROM shortlist_talent WHERE shortlist_id=?',(l['id'],))]; lists.append(d)
                    return self.send_json({'offers':offers,'deals':deals,'applications':apps,'favorites':fav,'shortlists':lists,'collaborationRequests':requests})
                elif u['role']=='talent':
                    offers=[dict(r) for r in c.execute('SELECT o.*,u.name brand_name FROM offers o JOIN users u ON u.id=o.brand_id WHERE talent_id=? ORDER BY o.created_at DESC',(u['id'],))]
                    deals=[dict(r) for r in c.execute('SELECT d.*,u.name brand_name FROM deals d JOIN users u ON u.id=d.brand_id WHERE talent_id=? ORDER BY d.created_at DESC',(u['id'],))]
                    apps=[dict(r) for r in c.execute('SELECT a.*,c.name campaign_name FROM applications a JOIN campaigns c ON c.id=a.campaign_id WHERE talent_id=? ORDER BY a.created_at DESC',(u['id'],))]
                    invites=[dict(r) for r in c.execute('SELECT i.*,c.name campaign_name,c.brand_id,b.name brand_name FROM campaign_invites i JOIN campaigns c ON c.id=i.campaign_id JOIN users b ON b.id=c.brand_id WHERE i.talent_id=? ORDER BY i.created_at DESC',(u['id'],))]
                    requests=[dict(r) for r in c.execute('SELECT r.*,b.name brand_name,b.verified brand_verified FROM collaboration_requests r JOIN users b ON b.id=r.brand_id WHERE r.talent_id=? ORDER BY r.updated_at DESC',(u['id'],))]
                    return self.send_json({'offers':offers,'deals':deals,'applications':apps,'invitations':invites,'collaborationRequests':requests})
                return self.send_json({'users':c.execute('SELECT COUNT(*) n FROM users').fetchone()['n'],'campaigns':c.execute('SELECT COUNT(*) n FROM campaigns').fetchone()['n'],'deals':c.execute('SELECT COUNT(*) n FROM deals').fetchone()['n']})
            if path=='/api/deals':
                u=self.require(c); 
                if not u:return
                if u['role']=='brand': rows=c.execute('SELECT d.*,u.name other_name FROM deals d JOIN users u ON u.id=d.talent_id WHERE d.brand_id=? ORDER BY d.created_at DESC',(u['id'],))
                elif u['role']=='talent': rows=c.execute('SELECT d.*,u.name other_name FROM deals d JOIN users u ON u.id=d.brand_id WHERE d.talent_id=? ORDER BY d.created_at DESC',(u['id'],))
                else: rows=c.execute('SELECT d.*,u.name other_name FROM deals d JOIN users u ON u.id=d.talent_id ORDER BY d.created_at DESC')
                return self.send_json({'deals':[dict(r) for r in rows]})
            if path=='/api/messages':
                u=self.require(c)
                if not u:return
                if u['role']=='brand':
                    rows=c.execute("SELECT r.*,t.name other_name,t.profile_json FROM collaboration_requests r JOIN users t ON t.id=r.talent_id WHERE r.brand_id=? AND r.status='Chat Open' ORDER BY r.updated_at DESC",(u['id'],))
                elif u['role']=='talent':
                    rows=c.execute("SELECT r.*,b.name other_name,b.profile_json FROM collaboration_requests r JOIN users b ON b.id=r.brand_id WHERE r.talent_id=? AND r.status='Chat Open' ORDER BY r.updated_at DESC",(u['id'],))
                else:
                    rows=[]
                chats=[]
                for row in rows:
                    item=dict(row); item.pop('profile_json',None); chats.append(item)
                return self.send_json({'chats':chats})
            if path.startswith('/api/chats/'):
                u=self.require(c)
                if not u:return
                rid=path.split('/')[3]
                row=c.execute('SELECT r.*,t.name talent_name,b.name brand_name FROM collaboration_requests r JOIN users t ON t.id=r.talent_id JOIN users b ON b.id=r.brand_id WHERE r.id=?',(rid,)).fetchone()
                if not row:return self.send_json({'error':'Chat not found'},404)
                request=dict(row)
                if request['status']!='Chat Open' or (u['role']!='admin' and u['id'] not in (request['talent_id'],request['brand_id'])):return self.send_json({'error':'Not allowed'},403)
                messages=[dict(r) for r in c.execute('SELECT m.*,u.name from_name FROM collaboration_messages m JOIN users u ON u.id=m.from_user WHERE request_id=? ORDER BY m.created_at',(rid,))]
                return self.send_json({'request':request,'messages':messages})
            if path.startswith('/api/deals/'):
                u=self.require(c); 
                if not u:return
                did=path.split('/')[3]; d=c.execute('SELECT * FROM deals WHERE id=?',(did,)).fetchone()
                if not d:return self.send_json({'error':'Not found'},404)
                dd=dict(d)
                if u['role']!='admin' and u['id'] not in (dd['brand_id'],dd['talent_id']):return self.send_json({'error':'Not allowed'},403)
                msgs=[dict(r) for r in c.execute('SELECT m.*,u.name from_name FROM deal_messages m JOIN users u ON u.id=m.from_user WHERE deal_id=? ORDER BY m.created_at',(did,))]
                return self.send_json({'deal':dd,'messages':msgs})
            if path=='/api/notifications':
                u=self.require(c); 
                if not u:return
                rows=[dict(r) for r in c.execute('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50',(u['id'],))]
                return self.send_json({'notifications':rows})
            if path=='/api/admin/users':
                u=self.require(c,['admin']);
                if not u:return
                rows=[public_user(r) for r in c.execute('SELECT * FROM users ORDER BY created_at DESC')]
                return self.send_json({'users':rows})
            return self.send_json({'error':'Not found'},404)
        finally:c.close()
    def do_POST(self):
        path=urlparse(self.path).path; data=self.body()
        if data is None:return
        c=db()
        try:
            if path=='/api/signup':
                email=clean_text(data.get('email',''),254).lower(); password=str(data.get('password','')); role=data.get('role'); name=clean_text(data.get('name',''),120)
                if role not in ('brand','talent') or '@' not in email or len(password)<8 or not name:return self.send_json({'error':'Complete all required fields; use a valid email and a password of at least 8 characters.'},400)
                if c.execute('SELECT 1 FROM users WHERE email=?',(email,)).fetchone():return self.send_json({'error':'Email already exists.'},409)
                id=uid('user'); profile={'country':data.get('country',''),'city':data.get('city',''),'bio':'','talentTypes':data.get('talentTypes',[]) if role=='talent' else None,'categories':[],'languages':[],'platforms':[],'services':[],'portfolio':[],'onboardingComplete':False}
                c.execute('INSERT INTO users VALUES(?,?,?,?,?,?,?,?,?)',(id,email,hash_password(password),role,name,0,0,json.dumps(profile),now())); token=secrets.token_urlsafe(32); c.execute('INSERT INTO sessions VALUES(?,?,?)',(token,id,int(time.time())+SESSION_DAYS*86400)); c.commit(); return self.send_json({'user':public_user(c.execute('SELECT * FROM users WHERE id=?',(id,)).fetchone())},201,session_cookie(token,SESSION_DAYS*86400))
            if path=='/api/login':
                r=c.execute('SELECT * FROM users WHERE email=?',(str(data.get('email','')).lower(),)).fetchone()
                if not r or not verify_password(str(data.get('password','')),r['password_hash']):return self.send_json({'error':'Email or password is incorrect.'},401)
                if r['suspended']:return self.send_json({'error':'This account is suspended.'},403)
                token=secrets.token_urlsafe(32); c.execute('INSERT INTO sessions VALUES(?,?,?)',(token,r['id'],int(time.time())+SESSION_DAYS*86400)); c.commit(); return self.send_json({'user':public_user(r)},200,session_cookie(token,SESSION_DAYS*86400))
            if path=='/api/logout':
                token=self.cookies().get('muse_session');
                if token:c.execute('DELETE FROM sessions WHERE token=?',(token,)); c.commit()
                return self.send_json({'ok':True},200,session_cookie('',0))
            if path.startswith('/api/brands/') and path.endswith('/requests'):
                u=self.require(c,['talent'])
                if not u:return
                if not is_live_profile(u):return self.send_json({'error':'Complete your profile before requesting a collaboration.'},400)
                bid=path.split('/')[3]
                target=public_user(c.execute("SELECT * FROM users WHERE id=? AND role='brand' AND suspended=0",(bid,)).fetchone())
                if not is_live_profile(target):return self.send_json({'error':'Brand profile is not available.'},404)
                existing=c.execute('SELECT id,status FROM collaboration_requests WHERE talent_id=? AND brand_id=?',(u['id'],bid)).fetchone()
                if existing:
                    return self.send_json({'error':'You already sent a collaboration request to this brand.'},409)
                note=clean_text(data.get('note'),1200)
                rid=uid('request'); created=now()
                c.execute('INSERT INTO collaboration_requests VALUES(?,?,?,?,?,?,?)',(rid,u['id'],bid,note,'Pending',created,created))
                c.execute('INSERT INTO notifications VALUES(?,?,?,?,?)',(uid('n'),bid,f"{u['name']} requested a collaboration",0,created))
                c.commit(); return self.send_json({'id':rid,'status':'Pending'},201)
            if path.startswith('/api/requests/') and path.endswith('/open-chat'):
                u=self.require(c,['brand'])
                if not u:return
                rid=path.split('/')[3]
                request=c.execute('SELECT * FROM collaboration_requests WHERE id=? AND brand_id=?',(rid,u['id'])).fetchone()
                if not request:return self.send_json({'error':'Collaboration request not found'},404)
                if request['status']!='Pending':return self.send_json({'error':'This request has already been handled.'},409)
                updated=now()
                c.execute('UPDATE collaboration_requests SET status=?,updated_at=? WHERE id=?',('Chat Open',updated,rid))
                c.execute('INSERT INTO notifications VALUES(?,?,?,?,?)',(uid('n'),request['talent_id'],f"{u['name']} opened a chat for your collaboration request",0,updated))
                c.commit(); return self.send_json({'id':rid,'status':'Chat Open'})
            if path.startswith('/api/requests/') and path.endswith('/messages'):
                u=self.require(c)
                if not u:return
                rid=path.split('/')[3]
                request=c.execute('SELECT * FROM collaboration_requests WHERE id=?',(rid,)).fetchone()
                if not request or request['status']!='Chat Open' or (u['role']!='admin' and u['id'] not in (request['talent_id'],request['brand_id'])):
                    return self.send_json({'error':'Chat is not available.'},403)
                text=clean_text(data.get('text'),5000); file_url=uploaded_url(data.get('fileUrl')); file_name=clean_text(data.get('fileName'),180) if file_url else None
                if not text and not file_url:return self.send_json({'error':'Write a message or attach a file.'},400)
                created=now()
                c.execute('INSERT INTO collaboration_messages VALUES(?,?,?,?,?,?,?)',(uid('chatmsg'),rid,u['id'],text,file_name,file_url or None,created))
                c.execute('UPDATE collaboration_requests SET updated_at=? WHERE id=?',(created,rid))
                other=request['talent_id'] if u['id']==request['brand_id'] else request['brand_id']
                c.execute('INSERT INTO notifications VALUES(?,?,?,?,?)',(uid('n'),other,f"New chat message from {u['name']}",0,created))
                c.commit(); return self.send_json({'ok':True},201)
            if path=='/api/campaigns':
                u=self.require(c,['brand']);
                if not u:return
                name=clean_text(data.get('name'),140); description=clean_text(data.get('description'),3000)
                budget_min=money_value(data.get('budgetMin')); budget_max=money_value(data.get('budgetMax')); slots=whole_number(data.get('slots'))
                visibility=data.get('visibility','Public')
                if not name or not description or budget_min is None or budget_max is None or budget_min<=0 or budget_max<budget_min or not slots:return self.send_json({'error':'Add a name, description, valid budget range and talent count.'},400)
                if visibility not in ('Public','Invite Only'):return self.send_json({'error':'Invalid campaign visibility.'},400)
                id=uid('camp'); vals=(id,u['id'],name,description,clean_text(data.get('talentType','Influencer / Model'),80),clean_text(data.get('category'),80),clean_text(data.get('country'),120),clean_text(data.get('city'),120),clean_text(data.get('platform'),120),clean_text(data.get('deliverables'),1000),budget_min,budget_max,'USD',clean_text(data.get('deadline'),30),slots,visibility,'Open',now())
                c.execute('INSERT INTO campaigns VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',vals); c.commit(); return self.send_json({'id':id},201)
            if path.startswith('/api/campaigns/') and path.endswith('/invite'):
                u=self.require(c,['brand']);
                if not u:return
                cid=path.split('/')[3]; talent_id=str(data.get('talentId',''))
                camp=c.execute('SELECT id,name FROM campaigns WHERE id=? AND brand_id=? AND status!=?',(cid,u['id'],'Deleted')).fetchone()
                if not camp:return self.send_json({'error':'Campaign not found'},404)
                target=c.execute("SELECT id FROM users WHERE id=? AND role='talent' AND suspended=0",(talent_id,)).fetchone()
                if not target:return self.send_json({'error':'Talent not found'},404)
                if c.execute('SELECT 1 FROM campaign_invites WHERE campaign_id=? AND talent_id=?',(cid,talent_id)).fetchone():return self.send_json({'error':'Talent is already invited to this campaign.'},409)
                c.execute('INSERT INTO campaign_invites VALUES(?,?,?,?,?)',(uid('inv'),cid,talent_id,'Invited',now()))
                c.execute('INSERT INTO notifications VALUES(?,?,?,?,?)',(uid('n'),talent_id,f"You were invited to {camp['name']} by {u['name']}",0,now()))
                c.commit(); return self.send_json({'ok':True},201)
            if path.startswith('/api/campaigns/') and path.endswith('/apply'):
                u=self.require(c,['talent']);
                if not u:return
                cid=path.split('/')[3]
                camp=c.execute('SELECT visibility,status FROM campaigns WHERE id=?',(cid,)).fetchone()
                if not camp or camp['status']!='Open':return self.send_json({'error':'Campaign is not open.'},400)
                if camp['visibility']=='Invite Only' and not c.execute('SELECT 1 FROM campaign_invites WHERE campaign_id=? AND talent_id=?',(cid,u['id'])).fetchone():return self.send_json({'error':'This campaign is invite only.'},403)
                if c.execute('SELECT 1 FROM applications WHERE campaign_id=? AND talent_id=?',(cid,u['id'])).fetchone():return self.send_json({'error':'You already applied.'},409)
                proposal=clean_text(data.get('proposal'),3000); price=money_value(data.get('price'))
                if not proposal or price is None or price<=0:return self.send_json({'error':'Add a proposal and a valid price.'},400)
                c.execute('INSERT INTO applications VALUES(?,?,?,?,?,?,?)',(uid('app'),cid,u['id'],proposal,price,'Applied',now())); c.execute('UPDATE campaign_invites SET status=? WHERE campaign_id=? AND talent_id=?',('Applied',cid,u['id'])); brand=c.execute('SELECT brand_id,name FROM campaigns WHERE id=?',(cid,)).fetchone();
                if brand:c.execute('INSERT INTO notifications VALUES(?,?,?,?,?)',(uid('n'),brand['brand_id'],f"New application for {brand['name']}",0,now()))
                c.commit(); return self.send_json({'ok':True},201)
            if path=='/api/offers':
                u=self.require(c,['brand']);
                if not u:return
                talent_id=clean_text(data.get('talentId'),80); title=clean_text(data.get('title'),160); details=clean_text(data.get('details'),3000); deliverables=clean_text(data.get('deliverables'),1200); date=clean_text(data.get('date'),30); price=money_value(data.get('price'))
                target=c.execute("SELECT id FROM users WHERE id=? AND role='talent' AND suspended=0",(talent_id,)).fetchone()
                if not target:return self.send_json({'error':'Talent profile is not available.'},404)
                if not title or not details or not deliverables or not date or price is None or price<=0:return self.send_json({'error':'Complete the offer details and enter a valid price.'},400)
                oid=uid('offer')
                c.execute(
                    'INSERT INTO offers(id,brand_id,talent_id,title,details,deliverables,date,price,currency,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                    (oid,u['id'],talent_id,title,details,deliverables,date,price,'USD','Pending',now())
                )
                c.execute('INSERT INTO notifications VALUES(?,?,?,?,?)',(uid('n'),talent_id,f"You received an offer from {u['name']}",0,now()))
                c.commit(); return self.send_json({'id':oid},201)
            if path.startswith('/api/offers/') and path.endswith('/respond'):
                u=self.require(c);
                if not u:return
                oid=path.split('/')[3]; o=c.execute('SELECT * FROM offers WHERE id=?',(oid,)).fetchone()
                if not o:return self.send_json({'error':'Offer not found'},404)
                status=data.get('status')
                if u['role']=='talent':
                    if o['talent_id']!=u['id']:return self.send_json({'error':'Not allowed'},403)
                    if o['status']!='Pending':return self.send_json({'error':'This offer has already been answered.'},409)
                    if status not in ('Accepted','Declined','Countered'):return self.send_json({'error':'Invalid offer response.'},400)
                    if status=='Countered':
                        counter_price=money_value(data.get('counterPrice'))
                        counter_note=clean_text(data.get('counterNote'),1200)
                        if counter_price is None or counter_price<=0:return self.send_json({'error':'Enter a valid counter offer price.'},400)
                        c.execute('UPDATE offers SET status=?,counter_price=?,counter_note=?,countered_at=? WHERE id=?',('Countered',counter_price,counter_note,now(),oid))
                        c.execute('INSERT INTO notifications VALUES(?,?,?,?,?)',(uid('n'),o['brand_id'],f"{u['name']} sent a counter offer for {o['title']}",0,now()))
                    else:
                        c.execute('UPDATE offers SET status=? WHERE id=?',(status,oid))
                        if status=='Accepted':
                            create_deal_for_offer(c,o,o['price'])
                            c.execute('INSERT INTO notifications VALUES(?,?,?,?,?)',(uid('n'),o['brand_id'],f"{u['name']} accepted your offer",0,now()))
                        else:
                            c.execute('INSERT INTO notifications VALUES(?,?,?,?,?)',(uid('n'),o['brand_id'],f"{u['name']} declined your offer",0,now()))
                    c.commit(); return self.send_json({'ok':True})
                if u['role']=='brand':
                    if o['brand_id']!=u['id']:return self.send_json({'error':'Not allowed'},403)
                    if o['status']!='Countered':return self.send_json({'error':'This offer does not have a pending counter.'},409)
                    if status not in ('Accepted','Declined'):return self.send_json({'error':'Invalid counter response.'},400)
                    c.execute('UPDATE offers SET status=? WHERE id=?',(status,oid))
                    if status=='Accepted':
                        create_deal_for_offer(c,o,o['counter_price'] or o['price'])
                        text=f"{u['name']} accepted your counter offer"
                    else:
                        text=f"{u['name']} declined your counter offer"
                    c.execute('INSERT INTO notifications VALUES(?,?,?,?,?)',(uid('n'),o['talent_id'],text,0,now()))
                    c.commit(); return self.send_json({'ok':True})
                return self.send_json({'error':'Not allowed'},403)
            if path.startswith('/api/deals/') and path.endswith('/messages'):
                u=self.require(c);
                if not u:return
                did=path.split('/')[3]; d=c.execute('SELECT * FROM deals WHERE id=?',(did,)).fetchone();
                if not d or (u['role']!='admin' and u['id'] not in (d['brand_id'],d['talent_id'])):return self.send_json({'error':'Not allowed'},403)
                text=clean_text(data.get('text'),5000); file_url=uploaded_url(data.get('fileUrl')); file_name=clean_text(data.get('fileName'),180) if file_url else None
                if not text and not file_url:return self.send_json({'error':'Write a message or attach a file.'},400)
                c.execute('INSERT INTO deal_messages VALUES(?,?,?,?,?,?,?)',(uid('msg'),did,u['id'],text,file_name,file_url or None,now())); c.commit(); return self.send_json({'ok':True},201)
            if path.startswith('/api/deals/') and path.endswith('/payment/plan'):
                u=self.require(c)
                if not u:return
                did=path.split('/')[3]; d=c.execute('SELECT * FROM deals WHERE id=?',(did,)).fetchone()
                if not d or u['id'] not in (d['brand_id'],d['talent_id']):return self.send_json({'error':'Not allowed'},403)
                if (d['payment_status'] or 'Not set') in ('Transfer Sent','Received'):
                    return self.send_json({'error':'Payment tracking cannot be changed after a transfer is marked as sent.'},409)
                plan=clean_text(data.get('paymentPlan'),40)
                if plan not in ('Full','Deposit','Milestones'):return self.send_json({'error':'Choose Full, Deposit or Milestones.'},400)
                note=clean_text(data.get('paymentNote'),800)
                updated=now()
                c.execute('UPDATE deals SET payment_plan=?,payment_note=?,payment_status=? WHERE id=?',(plan,note,'Planned',did))
                other=d['talent_id'] if u['id']==d['brand_id'] else d['brand_id']
                c.execute('INSERT INTO notifications VALUES(?,?,?,?,?)',(uid('n'),other,f"{u['name']} set up payment tracking for {d['title']}",0,updated))
                c.commit(); return self.send_json({'ok':True,'paymentStatus':'Planned'})
            if path.startswith('/api/deals/') and path.endswith('/payment/sent'):
                u=self.require(c,['brand'])
                if not u:return
                did=path.split('/')[3]; d=c.execute('SELECT * FROM deals WHERE id=? AND brand_id=?',(did,u['id'])).fetchone()
                if not d:return self.send_json({'error':'Not allowed'},403)
                if (d['payment_status'] or 'Not set')!='Planned':return self.send_json({'error':'Set a payment plan before marking a transfer as sent.'},409)
                updated=now()
                c.execute('UPDATE deals SET payment_status=?,payment_sent_at=? WHERE id=?',('Transfer Sent',updated,did))
                c.execute('INSERT INTO notifications VALUES(?,?,?,?,?)',(uid('n'),d['talent_id'],f"{u['name']} marked the payment transfer as sent for {d['title']}",0,updated))
                c.commit(); return self.send_json({'ok':True,'paymentStatus':'Transfer Sent'})
            if path.startswith('/api/deals/') and path.endswith('/payment/received'):
                u=self.require(c,['talent'])
                if not u:return
                did=path.split('/')[3]; d=c.execute('SELECT * FROM deals WHERE id=? AND talent_id=?',(did,u['id'])).fetchone()
                if not d:return self.send_json({'error':'Not allowed'},403)
                if (d['payment_status'] or 'Not set')!='Transfer Sent':return self.send_json({'error':'The brand has not marked a transfer as sent yet.'},409)
                updated=now()
                c.execute('UPDATE deals SET payment_status=?,payment_received_at=? WHERE id=?',('Received',updated,did))
                c.execute('INSERT INTO notifications VALUES(?,?,?,?,?)',(uid('n'),d['brand_id'],f"{u['name']} confirmed payment receipt for {d['title']}",0,updated))
                c.commit(); return self.send_json({'ok':True,'paymentStatus':'Received'})
            if path.startswith('/api/deals/') and path.endswith('/status'):
                u=self.require(c);
                if not u:return
                did=path.split('/')[3]; d=c.execute('SELECT * FROM deals WHERE id=?',(did,)).fetchone();
                if not d or (u['role']!='admin' and u['id'] not in (d['brand_id'],d['talent_id'])):return self.send_json({'error':'Not allowed'},403)
                status=data.get('status'); allowed=['Accepted','In Progress','Submitted','Approved','Completed']
                if status not in allowed:return self.send_json({'error':'Invalid status'},400)
                c.execute('UPDATE deals SET status=? WHERE id=?',(status,did)); c.commit(); return self.send_json({'ok':True})
            if path.startswith('/api/favorites/'):
                u=self.require(c,['brand']);
                if not u:return
                tid=path.split('/')[-1]
                if not c.execute("SELECT 1 FROM users WHERE id=? AND role='talent' AND suspended=0",(tid,)).fetchone():return self.send_json({'error':'Talent profile is not available.'},404)
                if c.execute('SELECT 1 FROM favorites WHERE brand_id=? AND talent_id=?',(u['id'],tid)).fetchone():c.execute('DELETE FROM favorites WHERE brand_id=? AND talent_id=?',(u['id'],tid)); saved=False
                else:c.execute('INSERT INTO favorites VALUES(?,?)',(u['id'],tid)); saved=True
                c.commit(); return self.send_json({'saved':saved})
            if path=='/api/shortlists':
                u=self.require(c,['brand']);
                if not u:return
                name=clean_text(data.get('name','New list'),80) or 'New list'
                sid=uid('list'); c.execute('INSERT INTO shortlists VALUES(?,?,?,?)',(sid,u['id'],name,now())); c.commit(); return self.send_json({'id':sid},201)
            if path.startswith('/api/shortlists/') and path.endswith('/toggle'):
                u=self.require(c,['brand']);
                if not u:return
                sid=path.split('/')[3]; tid=data.get('talentId'); owner=c.execute('SELECT 1 FROM shortlists WHERE id=? AND brand_id=?',(sid,u['id'])).fetchone();
                if not owner:return self.send_json({'error':'List not found'},404)
                if not c.execute("SELECT 1 FROM users WHERE id=? AND role='talent' AND suspended=0",(tid,)).fetchone():return self.send_json({'error':'Talent profile is not available.'},404)
                if c.execute('SELECT 1 FROM shortlist_talent WHERE shortlist_id=? AND talent_id=?',(sid,tid)).fetchone():c.execute('DELETE FROM shortlist_talent WHERE shortlist_id=? AND talent_id=?',(sid,tid)); added=False
                else:c.execute('INSERT INTO shortlist_talent VALUES(?,?)',(sid,tid)); added=True
                c.commit(); return self.send_json({'added':added})
            if path=='/api/upload':
                u=self.require(c); 
                if not u:return
                raw=data.get('data',''); filename=os.path.basename(clean_text(data.get('filename','file'),180))
                ext=Path(filename).suffix.lower()
                if ext not in ALLOWED_UPLOAD_EXTENSIONS:return self.send_json({'error':'Use an image, PDF, Office document or ZIP file.'},400)
                if ',' in raw:raw=raw.split(',',1)[1]
                try:blob=base64.b64decode(raw,validate=True)
                except:return self.send_json({'error':'Invalid file'},400)
                if len(blob)>MAX_UPLOAD_BYTES:return self.send_json({'error':'File too large (6 MB max).'},413)
                UPLOADS.mkdir(parents=True,exist_ok=True)
                target=f"{uuid.uuid4().hex}{ext}"
                temporary=UPLOADS/(target+'.uploading')
                temporary.write_bytes(blob)
                temporary.replace(UPLOADS/target)
                return self.send_json({'url':'/uploads/'+target,'name':filename},201)
            if path.startswith('/api/admin/users/') and path.endswith('/verify'):
                u=self.require(c,['admin']);
                if not u:return
                tid=path.split('/')[4]; r=c.execute('SELECT verified FROM users WHERE id=?',(tid,)).fetchone()
                if not r:return self.send_json({'error':'User not found'},404)
                c.execute('UPDATE users SET verified=? WHERE id=?',(0 if r['verified'] else 1,tid)); c.commit(); return self.send_json({'ok':True})
            if path.startswith('/api/admin/users/') and path.endswith('/suspend'):
                u=self.require(c,['admin']);
                if not u:return
                tid=path.split('/')[4]; r=c.execute('SELECT suspended FROM users WHERE id=?',(tid,)).fetchone();
                if not r:return self.send_json({'error':'User not found'},404)
                if tid==u['id']:return self.send_json({'error':'You cannot suspend your own admin account.'},400)
                c.execute('UPDATE users SET suspended=? WHERE id=?',(0 if r['suspended'] else 1,tid)); c.commit(); return self.send_json({'ok':True})
            return self.send_json({'error':'Not found'},404)
        finally:c.close()
    def do_PATCH(self):
        path=urlparse(self.path).path; data=self.body()
        if data is None:return
        c=db()
        try:
            if path=='/api/me':
                u=self.require(c); 
                if not u:return
                row=c.execute('SELECT * FROM users WHERE id=?',(u['id'],)).fetchone(); p=json.loads(row['profile_json'] or '{}')
                allowed={'bio','country','city','nationality','talentTypes','categories','languages','availability','startingRate','modelCategory','measurements','agency','industry','website','companySize','brandFocus','onboardingComplete'}
                for k in allowed:
                    if k in data:p[k]=data[k]
                if 'profilePhoto' in data:p['profilePhoto']=uploaded_url(data.get('profilePhoto'))
                if 'coverImage' in data:p['coverImage']=uploaded_url(data.get('coverImage'))
                if 'portfolio' in data and isinstance(data['portfolio'],list):
                    p['portfolio']=[uploaded_url(item) for item in data['portfolio'][:6] if uploaded_url(item)]
                if 'platforms' in data and isinstance(data['platforms'],list):
                    p['platforms']=[{'name':clean_text(item.get('name'),50),'handle':clean_text(item.get('handle'),100),'followers':money_value(item.get('followers')) or 0} for item in data['platforms'][:6] if isinstance(item,dict) and clean_text(item.get('name'),50)]
                if 'services' in data and isinstance(data['services'],list):
                    p['services']=[{'name':clean_text(item.get('name'),100),'price':money_value(item.get('price')) or 0} for item in data['services'][:6] if isinstance(item,dict) and clean_text(item.get('name'),100)]
                if 'brandTags' in data and isinstance(data['brandTags'],list):
                    p['brandTags']=[clean_text(item,50) for item in data['brandTags'][:8] if clean_text(item,50)]
                name=clean_text(data.get('name',row['name']),120) or row['name']
                c.execute('UPDATE users SET name=?,profile_json=? WHERE id=?',(name,json.dumps(p),u['id'])); c.commit(); return self.send_json({'user':public_user(c.execute('SELECT * FROM users WHERE id=?',(u['id'],)).fetchone())})
            return self.send_json({'error':'Not found'},404)
        finally:c.close()

if __name__=='__main__':
    init_db(); port=int(os.environ.get('PORT','8000')); print(f'MUSE running on http://localhost:{port}'); ThreadingHTTPServer(('0.0.0.0',port),Handler).serve_forever()
