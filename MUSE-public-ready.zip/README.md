# MUSE — Talent Marketplace V1

MUSE is a working marketplace for brands, influencers and models. It is a real, server-backed V1 rather than a static design.

## Included in V1

- Brand and Talent sign-up, sign-in and guided profile setup
- Influencer and Model profiles with portfolio, services, social audience, nationality, residence and availability
- Global discovery with filters for talent type, country, city, nationality, category, platform, followers, rate, language and availability
- Favorites and shortlists
- Brand campaigns with public and invite-only visibility
- Talent applications, brand review of applicants and direct offers
- Offer acceptance, decline and counter offers
- Deal rooms, milestones, messages and allowed file attachments
- Admin review, account verification and suspension
- Responsive premium fashion-tech interface

Payments, commission, subscriptions and AI matching are intentionally not part of V1.

## Local demo on Mac

Double-click <code>start.command</code>.

Or run:

~~~bash
cd muse-real
MUSE_DEMO_MODE=1 python3 server.py
~~~

Then open <code>http://localhost:8000</code>.

The demo mode creates test accounts only when the selected database is empty:

- Brand: <code>brand@demo.com</code> / <code>demo1234</code>
- Talent: <code>talent@demo.com</code> / <code>demo1234</code>
- Admin: <code>admin@demo.com</code> / <code>demo1234</code>

Never enable demo mode on a public launch.

## Local demo on Windows

Double-click <code>start.bat</code>, or run:

~~~bat
set MUSE_DEMO_MODE=1
python server.py
~~~

Python 3 is the only requirement. No package installation or external database is required for local use.

## Production launch

The launch archive intentionally contains no database or test accounts. On its first production start, MUSE creates an empty database and the first admin account from these environment variables:

~~~bash
MUSE_DB=/path/to/persistent/muse.db \
MUSE_BOOTSTRAP_ADMIN_EMAIL=admin@yourdomain.com \
MUSE_BOOTSTRAP_ADMIN_PASSWORD=use-a-long-unique-password \
MUSE_SECURE_COOKIES=1 \
python3 server.py
~~~

- Use a persistent disk for SQLite. For higher traffic, move to PostgreSQL.
- Set <code>MUSE_SECURE_COOKIES=1</code> only when the public site is served over HTTPS.
- Keep the bootstrap password private and use at least eight characters for every account.
- Uploaded files are limited to 6 MB and to supported images, PDFs, Office documents and ZIP files.

### Deploy-ready files

The project includes a <code>Dockerfile</code> and <code>render.yaml</code> for a public deployment. The Render configuration starts one Docker web service, keeps both the SQLite database and uploads on a persistent disk at <code>/var/data</code>, and asks for the first admin email and password privately during setup.

1. Put this folder in a Git repository.
2. Create a new Render Blueprint from that repository.
3. Keep the persistent disk enabled and provide a unique admin email and password when prompted.
4. Once it is live, add the chosen custom domain in the service settings.

The app uses the host's <code>PORT</code> automatically. Do not enable demo mode on the public service. For higher traffic, move from SQLite to PostgreSQL before adding multiple server instances.
